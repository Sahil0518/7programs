import Meals from "../food/Meals.js";

export const Home = () => {
    return <Meals/>
}